load('/python/michelangelo/uniflow/declarative/engine.star', 'run')
load('/python/michelangelo/uniflow/plugins/ray/task.star', factory_core_ray='task')
load('/python/michelangelo/uniflow/plugins/spark/task.star', factory_core_spark='spark_task')
REGISTRY = {'core/ray': {'factory': factory_core_ray, 'job_specs_key': 'ray', 'capabilities': ['retry']}, 'core/spark': {'factory': factory_core_spark, 'job_specs_key': 'spark', 'capabilities': ['retry']}}

def main(spec, params):
    return run(spec, params, REGISTRY)