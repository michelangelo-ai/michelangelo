load('/python/michelangelo/uniflow/declarative/engine.star', 'run')
load('/python/michelangelo/uniflow/plugins/ray/task.star', factory_core_ray='task')
REGISTRY = {'core/ray': {'factory': factory_core_ray, 'job_specs_key': 'ray', 'capabilities': ['retry']}}

def main(spec, params):
    return run(spec, params, REGISTRY)